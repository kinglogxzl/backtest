from distutils.core import setup
setup(name='backtest',
      url='https://github.com/kinglogxzl/backtest',
      version='1.0',
      py_modules=['context'],
      )
