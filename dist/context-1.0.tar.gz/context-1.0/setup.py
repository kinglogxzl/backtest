from distutils.core import setup
setup(name='context',
      version='1.0',
      py_modules=['context'],
      )
